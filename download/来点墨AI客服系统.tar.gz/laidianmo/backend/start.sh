#!/bin/bash
# 来点墨AI客服系统 - 启动脚本
cd "$(dirname "$0")"
pip3 install fastapi uvicorn sqlalchemy pyjwt 2>/dev/null
echo "正在启动来点墨AI客服系统..."
python3 -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
