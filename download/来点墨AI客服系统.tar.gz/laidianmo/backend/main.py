"""
来点墨书法艺术培训中心 - AI客服系统
FastAPI 主应用：前后端分离，JWT鉴权保护管理接口
"""
import os
from datetime import datetime
from typing import Optional

from fastapi import FastAPI, Depends, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from models import init_db, get_db, Admin, Category, Course, Teacher, Schedule, Campus, FAQ, Promotion, TrialBooking, OrgInfo
from auth import verify_password, hash_password, create_token, decode_token
from retriever import retrieve
from llm import chat as llm_chat

# ========== 初始化 ==========
app = FastAPI(title="来点墨AI客服系统", version="2.0.0")

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

FRONTEND_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "frontend")

@app.on_event("startup")
def startup():
    init_db()
    from seed import seed
    seed()


# ========== 鉴权依赖 ==========
def require_admin(authorization: str = Header(None)) -> dict:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="未登录")
    payload = decode_token(authorization[7:])
    if not payload:
        raise HTTPException(status_code=401, detail="登录已过期")
    return payload


# ========== 前端页面 ==========
@app.get("/")
async def index():
    return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))

@app.get("/admin")
async def admin_page():
    return FileResponse(os.path.join(FRONTEND_DIR, "admin.html"))


# ========== 公开接口（家长端） ==========

class ChatRequest(BaseModel):
    message: str
    history: list = []

@app.post("/api/chat")
async def chat(req: ChatRequest, db: Session = Depends(get_db)):
    """家长对话接口 - 无需登录"""
    if not req.message or len(req.message) > 500:
        raise HTTPException(status_code=400, detail="消息无效")
    try:
        context = retrieve(db, req.message)
        reply = llm_chat(req.message, context, req.history)
        return {"success": True, "reply": reply}
    except Exception as e:
        return {"success": False, "reply": "抱歉，服务暂时不可用，请拨打咨询电话 400-888-6688。"}


@app.post("/api/trial-booking")
async def trial_booking(data: dict, db: Session = Depends(get_db)):
    """体验课预约 - 无需登录"""
    booking = TrialBooking(
        parent_name=data.get("parent_name"),
        phone=data.get("phone"),
        child_name=data.get("child_name"),
        child_age=data.get("child_age"),
        course_id=data.get("course_id"),
        campus_id=data.get("campus_id"),
        preferred_time=data.get("preferred_time"),
        remark=data.get("remark"),
    )
    db.add(booking)
    db.commit()
    return {"success": True, "id": booking.id}


@app.get("/api/courses")
async def list_courses(db: Session = Depends(get_db)):
    """公开课程列表"""
    courses = db.query(Course).filter(Course.is_active == True).all()
    return {"success": True, "data": [_obj(c) for c in courses]}


@app.get("/api/campuses")
async def list_campuses(db: Session = Depends(get_db)):
    """公开校区列表"""
    campuses = db.query(Campus).filter(Campus.is_active == True).all()
    return {"success": True, "data": [_obj(c) for c in campuses]}


# ========== 管理员登录 ==========

class LoginRequest(BaseModel):
    username: str
    password: str

@app.post("/api/admin/login")
async def admin_login(req: LoginRequest, db: Session = Depends(get_db)):
    admin = db.query(Admin).filter(Admin.username == req.username).first()
    if not admin or not verify_password(req.password, admin.hashed_password):
        raise HTTPException(status_code=401, detail="用户名或密码错误")
    token = create_token({"sub": admin.username, "id": admin.id})
    return {"success": True, "token": token, "username": admin.username}


@app.post("/api/admin/change-password")
async def change_password(data: dict, admin=Depends(require_admin), db: Session = Depends(get_db)):
    admin_obj = db.query(Admin).filter(Admin.id == admin["id"]).first()
    if not verify_password(data.get("old_password", ""), admin_obj.hashed_password):
        raise HTTPException(status_code=400, detail="原密码错误")
    admin_obj.hashed_password = hash_password(data["new_password"])
    db.commit()
    return {"success": True}


# ========== 管理接口（需鉴权） ==========

# --- 课程分类 ---
@app.get("/api/admin/categories")
async def get_categories(admin=Depends(require_admin), db: Session = Depends(get_db)):
    return {"success": True, "data": [_obj(c) for c in db.query(Category).order_by(Category.sort_order).all()]}

@app.post("/api/admin/categories")
async def add_category(data: dict, admin=Depends(require_admin), db: Session = Depends(get_db)):
    if not data.get("name"): raise HTTPException(400, "名称不能为空")
    c = Category(name=data["name"], description=data.get("description"), sort_order=data.get("sort_order", 0))
    db.add(c); db.commit(); db.refresh(c)
    return {"success": True, "id": c.id}

@app.put("/api/admin/categories/{item_id}")
async def update_category(item_id: int, data: dict, admin=Depends(require_admin), db: Session = Depends(get_db)):
    c = db.query(Category).filter(Category.id == item_id).first()
    if not c: raise HTTPException(404, "不存在")
    for k in ["name","description","sort_order"]:
        if k in data: setattr(c, k, data[k])
    db.commit()
    return {"success": True}

@app.delete("/api/admin/categories/{item_id}")
async def delete_category(item_id: int, admin=Depends(require_admin), db: Session = Depends(get_db)):
    db.query(Category).filter(Category.id == item_id).delete()
    db.commit()
    return {"success": True}


# --- 课程 ---
@app.get("/api/admin/courses")
async def get_courses(admin=Depends(require_admin), db: Session = Depends(get_db)):
    courses = db.query(Course).order_by(Course.id.desc()).all()
    result = []
    for c in courses:
        d = _obj(c)
        cat = db.query(Category).filter(Category.id == c.category_id).first()
        d["category_name"] = cat.name if cat else ""
        result.append(d)
    return {"success": True, "data": result}

@app.post("/api/admin/courses")
async def add_course(data: dict, admin=Depends(require_admin), db: Session = Depends(get_db)):
    if not data.get("name"): raise HTTPException(400, "课程名不能为空")
    c = Course(**{k: data.get(k) for k in ["category_id","name","description","age_range","level","duration","total_sessions","price","price_unit","max_students","highlights"] if k in data})
    db.add(c); db.commit(); db.refresh(c)
    return {"success": True, "id": c.id}

@app.put("/api/admin/courses/{item_id}")
async def update_course(item_id: int, data: dict, admin=Depends(require_admin), db: Session = Depends(get_db)):
    c = db.query(Course).filter(Course.id == item_id).first()
    if not c: raise HTTPException(404, "不存在")
    for k in ["category_id","name","description","age_range","level","duration","total_sessions","price","price_unit","max_students","highlights","is_active"]:
        if k in data: setattr(c, k, data[k])
    db.commit()
    return {"success": True}

@app.delete("/api/admin/courses/{item_id}")
async def delete_course(item_id: int, admin=Depends(require_admin), db: Session = Depends(get_db)):
    c = db.query(Course).filter(Course.id == item_id).first()
    if c: c.is_active = False; db.commit()
    return {"success": True}


# --- 教师 ---
@app.get("/api/admin/teachers")
async def get_teachers(admin=Depends(require_admin), db: Session = Depends(get_db)):
    return {"success": True, "data": [_obj(t) for t in db.query(Teacher).order_by(Teacher.id.desc()).all()]}

@app.post("/api/admin/teachers")
async def add_teacher(data: dict, admin=Depends(require_admin), db: Session = Depends(get_db)):
    if not data.get("name"): raise HTTPException(400, "姓名不能为空")
    t = Teacher(**{k: data.get(k) for k in ["name","title","specialties","experience_years","education","awards","bio"] if k in data})
    db.add(t); db.commit(); db.refresh(t)
    return {"success": True, "id": t.id}

@app.put("/api/admin/teachers/{item_id}")
async def update_teacher(item_id: int, data: dict, admin=Depends(require_admin), db: Session = Depends(get_db)):
    t = db.query(Teacher).filter(Teacher.id == item_id).first()
    if not t: raise HTTPException(404, "不存在")
    for k in ["name","title","specialties","experience_years","education","awards","bio","is_active"]:
        if k in data: setattr(t, k, data[k])
    db.commit()
    return {"success": True}

@app.delete("/api/admin/teachers/{item_id}")
async def delete_teacher(item_id: int, admin=Depends(require_admin), db: Session = Depends(get_db)):
    t = db.query(Teacher).filter(Teacher.id == item_id).first()
    if t: t.is_active = False; db.commit()
    return {"success": True}


# --- 排课 ---
@app.get("/api/admin/schedules")
async def get_schedules(admin=Depends(require_admin), db: Session = Depends(get_db)):
    items = db.query(Schedule).order_by(Schedule.day_of_week, Schedule.start_time).all()
    result = []
    for s in items:
        d = _obj(s)
        course = db.query(Course).filter(Course.id == s.course_id).first()
        teacher = db.query(Teacher).filter(Teacher.id == s.teacher_id).first()
        campus = db.query(Campus).filter(Campus.id == s.campus_id).first() if s.campus_id else None
        d["course_name"] = course.name if course else ""
        d["teacher_name"] = teacher.name if teacher else ""
        d["campus_name"] = campus.name if campus else ""
        result.append(d)
    return {"success": True, "data": result}

@app.post("/api/admin/schedules")
async def add_schedule(data: dict, admin=Depends(require_admin), db: Session = Depends(get_db)):
    s = Schedule(**{k: data.get(k) for k in ["course_id","teacher_id","campus_id","day_of_week","start_time","end_time","max_students","current_students"] if k in data})
    db.add(s); db.commit(); db.refresh(s)
    return {"success": True, "id": s.id}

@app.put("/api/admin/schedules/{item_id}")
async def update_schedule(item_id: int, data: dict, admin=Depends(require_admin), db: Session = Depends(get_db)):
    s = db.query(Schedule).filter(Schedule.id == item_id).first()
    if not s: raise HTTPException(404, "不存在")
    for k in ["course_id","teacher_id","campus_id","day_of_week","start_time","end_time","max_students","current_students","is_active"]:
        if k in data: setattr(s, k, data[k])
    db.commit()
    return {"success": True}

@app.delete("/api/admin/schedules/{item_id}")
async def delete_schedule(item_id: int, admin=Depends(require_admin), db: Session = Depends(get_db)):
    s = db.query(Schedule).filter(Schedule.id == item_id).first()
    if s: s.is_active = False; db.commit()
    return {"success": True}


# --- 校区 ---
@app.get("/api/admin/campuses")
async def get_campuses(admin=Depends(require_admin), db: Session = Depends(get_db)):
    return {"success": True, "data": [_obj(c) for c in db.query(Campus).all()]}

@app.post("/api/admin/campuses")
async def add_campus(data: dict, admin=Depends(require_admin), db: Session = Depends(get_db)):
    if not data.get("name"): raise HTTPException(400, "名称不能为空")
    c = Campus(**{k: data.get(k) for k in ["name","address","phone","business_hours","transportation"] if k in data})
    db.add(c); db.commit(); db.refresh(c)
    return {"success": True, "id": c.id}

@app.put("/api/admin/campuses/{item_id}")
async def update_campus(item_id: int, data: dict, admin=Depends(require_admin), db: Session = Depends(get_db)):
    c = db.query(Campus).filter(Campus.id == item_id).first()
    if not c: raise HTTPException(404, "不存在")
    for k in ["name","address","phone","business_hours","transportation","is_active"]:
        if k in data: setattr(c, k, data[k])
    db.commit()
    return {"success": True}

@app.delete("/api/admin/campuses/{item_id}")
async def delete_campus(item_id: int, admin=Depends(require_admin), db: Session = Depends(get_db)):
    c = db.query(Campus).filter(Campus.id == item_id).first()
    if c: c.is_active = False; db.commit()
    return {"success": True}


# --- FAQ ---
@app.get("/api/admin/faqs")
async def get_faqs(admin=Depends(require_admin), db: Session = Depends(get_db)):
    return {"success": True, "data": [_obj(f) for f in db.query(FAQ).order_by(FAQ.sort_order).all()]}

@app.post("/api/admin/faqs")
async def add_faq(data: dict, admin=Depends(require_admin), db: Session = Depends(get_db)):
    if not data.get("question"): raise HTTPException(400, "问题不能为空")
    f = FAQ(**{k: data.get(k) for k in ["category","question","answer","sort_order"] if k in data})
    db.add(f); db.commit(); db.refresh(f)
    return {"success": True, "id": f.id}

@app.put("/api/admin/faqs/{item_id}")
async def update_faq(item_id: int, data: dict, admin=Depends(require_admin), db: Session = Depends(get_db)):
    f = db.query(FAQ).filter(FAQ.id == item_id).first()
    if not f: raise HTTPException(404, "不存在")
    for k in ["category","question","answer","sort_order","is_active"]:
        if k in data: setattr(f, k, data[k])
    db.commit()
    return {"success": True}

@app.delete("/api/admin/faqs/{item_id}")
async def delete_faq(item_id: int, admin=Depends(require_admin), db: Session = Depends(get_db)):
    f = db.query(FAQ).filter(FAQ.id == item_id).first()
    if f: f.is_active = False; db.commit()
    return {"success": True}


# --- 优惠活动 ---
@app.get("/api/admin/promotions")
async def get_promotions(admin=Depends(require_admin), db: Session = Depends(get_db)):
    return {"success": True, "data": [_obj(p) for p in db.query(Promotion).order_by(Promotion.id.desc()).all()]}

@app.post("/api/admin/promotions")
async def add_promotion(data: dict, admin=Depends(require_admin), db: Session = Depends(get_db)):
    if not data.get("title"): raise HTTPException(400, "标题不能为空")
    p = Promotion(**{k: data.get(k) for k in ["title","description","discount_type","discount_value","start_date","end_date","conditions"] if k in data})
    db.add(p); db.commit(); db.refresh(p)
    return {"success": True, "id": p.id}

@app.put("/api/admin/promotions/{item_id}")
async def update_promotion(item_id: int, data: dict, admin=Depends(require_admin), db: Session = Depends(get_db)):
    p = db.query(Promotion).filter(Promotion.id == item_id).first()
    if not p: raise HTTPException(404, "不存在")
    for k in ["title","description","discount_type","discount_value","start_date","end_date","conditions","is_active"]:
        if k in data: setattr(p, k, data[k])
    db.commit()
    return {"success": True}

@app.delete("/api/admin/promotions/{item_id}")
async def delete_promotion(item_id: int, admin=Depends(require_admin), db: Session = Depends(get_db)):
    p = db.query(Promotion).filter(Promotion.id == item_id).first()
    if p: p.is_active = False; db.commit()
    return {"success": True}


# --- 体验课预约 ---
@app.get("/api/admin/bookings")
async def get_bookings(admin=Depends(require_admin), db: Session = Depends(get_db)):
    return {"success": True, "data": [_obj(b) for b in db.query(TrialBooking).order_by(TrialBooking.id.desc()).all()]}

@app.put("/api/admin/bookings/{item_id}")
async def update_booking(item_id: int, data: dict, admin=Depends(require_admin), db: Session = Depends(get_db)):
    b = db.query(TrialBooking).filter(TrialBooking.id == item_id).first()
    if not b: raise HTTPException(404, "不存在")
    if "status" in data: b.status = data["status"]
    db.commit()
    return {"success": True}


# --- 机构信息 ---
@app.get("/api/admin/org-info")
async def get_org_info(admin=Depends(require_admin), db: Session = Depends(get_db)):
    info = db.query(OrgInfo).first()
    return {"success": True, "data": _obj(info) if info else {}}

@app.put("/api/admin/org-info")
async def update_org_info(data: dict, admin=Depends(require_admin), db: Session = Depends(get_db)):
    info = db.query(OrgInfo).first()
    if not info:
        info = OrgInfo()
        db.add(info)
    for k in ["name","slogan","intro","philosophy","features","phone","wechat"]:
        if k in data: setattr(info, k, data[k])
    info.updated_at = datetime.now()
    db.commit()
    return {"success": True}


# ========== 工具函数 ==========
def _obj(model):
    """SQLAlchemy 模型转字典"""
    if not model: return {}
    d = {}
    for c in model.__table__.columns:
        v = getattr(model, c.name)
        if isinstance(v, datetime): v = v.strftime("%Y-%m-%d %H:%M:%S")
        d[c.name] = v
    return d


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
