"""
来点墨书法艺术培训中心 - 数据库模型
"""
import os
from datetime import datetime
from sqlalchemy import create_engine, Column, Integer, String, Text, Float, Boolean, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "laidianmo.db")
os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)

engine = create_engine(f"sqlite:///{DB_PATH}", connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class Admin(Base):
    """管理员账号"""
    __tablename__ = "admins"
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(50), unique=True, nullable=False)
    hashed_password = Column(String(200), nullable=False)
    created_at = Column(DateTime, default=datetime.now)


class Category(Base):
    """课程分类"""
    __tablename__ = "categories"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(50), nullable=False, unique=True)
    description = Column(Text)
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.now)


class Course(Base):
    """课程"""
    __tablename__ = "courses"
    id = Column(Integer, primary_key=True, autoincrement=True)
    category_id = Column(Integer, nullable=False)
    name = Column(String(100), nullable=False)
    description = Column(Text)
    age_range = Column(String(50))
    level = Column(String(50))
    duration = Column(String(50))
    total_sessions = Column(Integer)
    price = Column(Float)
    price_unit = Column(String(20), default="元/期")
    max_students = Column(Integer)
    highlights = Column(Text)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)


class Teacher(Base):
    """教师"""
    __tablename__ = "teachers"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(50), nullable=False)
    title = Column(String(100))
    specialties = Column(Text)
    experience_years = Column(Integer)
    education = Column(String(200))
    awards = Column(Text)
    bio = Column(Text)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.now)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)


class Schedule(Base):
    """排课"""
    __tablename__ = "schedules"
    id = Column(Integer, primary_key=True, autoincrement=True)
    course_id = Column(Integer, nullable=False)
    teacher_id = Column(Integer, nullable=False)
    campus_id = Column(Integer)
    day_of_week = Column(Integer, nullable=False)
    start_time = Column(String(10), nullable=False)
    end_time = Column(String(10), nullable=False)
    current_students = Column(Integer, default=0)
    max_students = Column(Integer)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.now)


class Campus(Base):
    """校区"""
    __tablename__ = "campuses"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False)
    address = Column(Text)
    phone = Column(String(30))
    business_hours = Column(String(100))
    transportation = Column(Text)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.now)


class FAQ(Base):
    """常见问题"""
    __tablename__ = "faqs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    category = Column(String(50))
    question = Column(Text, nullable=False)
    answer = Column(Text, nullable=False)
    sort_order = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.now)


class Promotion(Base):
    """优惠活动"""
    __tablename__ = "promotions"
    id = Column(Integer, primary_key=True, autoincrement=True)
    title = Column(String(200), nullable=False)
    description = Column(Text)
    discount_type = Column(String(50))
    discount_value = Column(String(200))
    start_date = Column(String(20))
    end_date = Column(String(20))
    conditions = Column(Text)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.now)


class TrialBooking(Base):
    """体验课预约"""
    __tablename__ = "trial_bookings"
    id = Column(Integer, primary_key=True, autoincrement=True)
    parent_name = Column(String(50))
    phone = Column(String(20))
    child_name = Column(String(50))
    child_age = Column(Integer)
    course_id = Column(Integer)
    campus_id = Column(Integer)
    preferred_time = Column(String(100))
    remark = Column(Text)
    status = Column(String(20), default="待确认")
    created_at = Column(DateTime, default=datetime.now)


class OrgInfo(Base):
    """机构信息"""
    __tablename__ = "org_info"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), default="来点墨书法艺术培训中心")
    slogan = Column(String(200))
    intro = Column(Text)
    philosophy = Column(Text)
    features = Column(Text)
    phone = Column(String(30))
    wechat = Column(String(100))
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)


def init_db():
    Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
