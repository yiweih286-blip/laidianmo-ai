"""
来点墨 - LLM 对话服务
调用 z-ai CLI 生成AI回复
"""
import subprocess
import json
import os

SYSTEM_PROMPT = """你是"来点墨书法艺术培训中心"的售前AI客服，名叫"小墨"。

## 角色
你是专业、亲切、耐心的书法培训顾问，服务对象是咨询课程的家长。

## 原则
1. 以数据库真实数据为准，不编造课程、价格、教师等信息
2. 语气温暖自然，像一位贴心的教育顾问
3. 主动引导：家长问题模糊时，询问孩子年龄、基础、兴趣方向
4. 诚实透明：数据库没有的信息，坦诚告知并建议联系校区
5. 适时推荐体验课，帮助家长做决策

## 格式
- 简洁清晰，适当分段和列表
- 价格明确标注
- 推荐课程说明理由

## 数据库信息
{CONTEXT}

---
请基于以上数据库信息回答。信息不足时建议家长联系校区。"""


def chat(user_message: str, db_context: str = "", history: list = None) -> str:
    """调用LLM生成回复"""
    full_msg = user_message
    if db_context:
        full_msg = f"[数据库检索结果]\n{db_context}\n\n[用户问题]\n{user_message}\n\n请基于数据库结果回答，不足时坦诚说明。"

    # 构建对话历史
    prompt_parts = []
    if history:
        for h in history[-8:]:
            role = "用户" if h["role"] == "user" else "小墨"
            prompt_parts.append(f"{role}：{h['content']}")
    prompt_parts.append(f"用户：{full_msg}")
    prompt_parts.append("小墨：")

    full_prompt = "\n".join(prompt_parts)

    try:
        result = subprocess.run(
            ["z-ai", "chat", "--prompt", full_prompt, "--system", SYSTEM_PROMPT.replace("{CONTEXT}", db_context or "（暂无数据）")],
            capture_output=True, text=True, timeout=30,
            cwd=os.path.dirname(os.path.abspath(__file__))
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    except Exception:
        pass

    # 备用回复
    if db_context and db_context != "（数据库暂无数据）":
        return f"感谢您的咨询！根据我们的信息：\n\n{db_context}\n\n如需更多详情，建议联系校区咨询。😊"
    return "抱歉，我暂时无法获取详细信息。建议您直接联系校区咨询，老师会为您专业解答！"
