"""
来点墨 - 种子数据
首次运行自动插入示例数据
"""
from datetime import datetime
from models import SessionLocal, Admin, Category, Course, Teacher, Schedule, Campus, FAQ, Promotion, OrgInfo
from auth import hash_password


def seed():
    db = SessionLocal()
    if db.query(Admin).first():
        db.close()
        return

    print("📝 插入种子数据...")

    # 管理员（默认密码 admin123）
    db.add(Admin(username="admin", hashed_password=hash_password("admin123")))

    # 机构信息
    db.add(OrgInfo(
        name="来点墨书法艺术培训中心",
        slogan="以墨养心，以书育人",
        intro="来点墨书法艺术培训中心是一家专注于书法艺术教育的专业培训机构，致力于传承中华书法文化，培养书法艺术人才。",
        philosophy="书法不仅是技艺的传承，更是心性的修炼。每一笔每一划，都是对美的追求和对传统文化的致敬。",
        features='["专业师资团队","小班制教学","个性化辅导","考级培训","赛事指导","作品展示"]',
        phone="400-888-6688",
        wechat="laidianmo_art"
    ))

    # 课程分类
    cats = [
        Category(name="硬笔书法", description="铅笔、钢笔等硬笔书写训练", sort_order=1),
        Category(name="毛笔书法", description="传统毛笔书法教学", sort_order=2),
        Category(name="国画", description="中国画基础与创作", sort_order=3),
        Category(name="篆刻", description="印章篆刻艺术", sort_order=4),
    ]
    db.add_all(cats)
    db.flush()

    # 课程
    courses = [
        Course(category_id=1, name="少儿硬笔启蒙班", description="从握笔姿势到基本笔画，系统培养孩子规范书写习惯。", age_range="5-7岁", level="启蒙", duration="60分钟/次", total_sessions=16, price=1280, price_unit="元/期", max_students=12, highlights="趣味教学,握笔矫正,笔画基础,作业辅导"),
        Course(category_id=1, name="少儿硬笔提高班", description="提升字形结构美感，培养书写速度与质量兼顾的能力。", age_range="7-10岁", level="初级", duration="60分钟/次", total_sessions=16, price=1480, price_unit="元/期", max_students=12, highlights="结构训练,提速书写,卷面美化,考级辅导"),
        Course(category_id=1, name="硬笔行书班", description="学习行书连笔技巧，提升日常书写效率与美感。", age_range="10岁以上", level="中级", duration="90分钟/次", total_sessions=16, price=1680, price_unit="元/期", max_students=10, highlights="连笔技巧,行书规范,日常应用,作品创作"),
        Course(category_id=2, name="少儿毛笔启蒙班", description="从文房四宝认识开始，学习毛笔基本笔画与简单汉字。", age_range="6-8岁", level="启蒙", duration="90分钟/次", total_sessions=16, price=1580, price_unit="元/期", max_students=10, highlights="笔墨启蒙,基本笔画,简单汉字,书法文化"),
        Course(category_id=2, name="毛笔楷书班", description="系统学习楷书技法，从颜柳欧赵入手，打牢书法根基。", age_range="8-12岁", level="初级", duration="90分钟/次", total_sessions=16, price=1780, price_unit="元/期", max_students=10, highlights="楷书技法,碑帖临摹,创作入门,考级辅导"),
        Course(category_id=2, name="毛笔行草班", description="学习行书草书技法，提升书法艺术表现力。", age_range="12岁以上", level="进阶", duration="90分钟/次", total_sessions=16, price=1980, price_unit="元/期", max_students=8, highlights="行草技法,经典临摹,自由创作,展览指导"),
        Course(category_id=2, name="成人毛笔修身班", description="以书修心，在繁忙生活中找到一份宁静。", age_range="成人", level="入门", duration="90分钟/次", total_sessions=16, price=1880, price_unit="元/期", max_students=12, highlights="修身养性,经典临摹,自由创作,文化交流"),
        Course(category_id=3, name="少儿国画启蒙班", description="学习国画基础技法，培养观察力和创造力。", age_range="6-10岁", level="启蒙", duration="90分钟/次", total_sessions=16, price=1680, price_unit="元/期", max_students=10, highlights="笔墨基础,花鸟入门,色彩感知,创意表达"),
        Course(category_id=4, name="篆刻入门班", description="学习篆刻基础，感受方寸之间的艺术魅力。", age_range="10岁以上", level="入门", duration="90分钟/次", total_sessions=12, price=1580, price_unit="元/期", max_students=8, highlights="篆书基础,刀法训练,印面设计,作品创作"),
    ]
    db.add_all(courses)
    db.flush()

    # 教师
    teachers = [
        Teacher(name="王墨轩", title="高级书法教师", specialties="毛笔楷书、行书", experience_years=15, education="中国美术学院书法硕士", awards="全国书法大赛金奖、省优秀教师", bio="教学风格严谨而不失趣味，善于引导学生发现书法之美。", is_active=True),
        Teacher(name="李清竹", title="资深硬笔教师", specialties="硬笔书法、规范字", experience_years=10, education="南京艺术学院书法本科", awards="全国硬笔书法大赛一等奖", bio="独创趣味笔画法，让孩子在快乐中掌握规范书写。", is_active=True),
        Teacher(name="张丹青", title="国画教师", specialties="花鸟画、山水画", experience_years=8, education="中央美术学院国画硕士", awards="全国青年国画展优秀奖", bio="注重培养学生的观察力和创造力，课堂生动有趣。", is_active=True),
        Teacher(name="陈石安", title="篆刻教师", specialties="篆刻、篆书", experience_years=12, education="西泠印社研修", awards="西泠印社篆刻展入展", bio="教学细致入微，让学生感受方寸之间的艺术魅力。", is_active=True),
    ]
    db.add_all(teachers)
    db.flush()

    # 校区
    campuses = [
        Campus(name="来点墨·总部校区", address="北京市朝阳区建国路88号SOHO现代城A座3层", phone="010-88886666", business_hours="周一至周日 9:00-21:00", transportation="地铁1号线大望路站B口步行5分钟", is_active=True),
        Campus(name="来点墨·海淀校区", address="北京市海淀区中关村大街18号科贸中心2层", phone="010-62227777", business_hours="周一至周日 9:00-20:30", transportation="地铁4号线中关村站C口步行3分钟", is_active=True),
    ]
    db.add_all(campuses)
    db.flush()

    # 排课
    schedules = [
        Schedule(course_id=1, teacher_id=2, campus_id=1, day_of_week=6, start_time="09:00", end_time="10:00", max_students=12, current_students=8, is_active=True),
        Schedule(course_id=1, teacher_id=2, campus_id=1, day_of_week=7, start_time="09:00", end_time="10:00", max_students=12, current_students=6, is_active=True),
        Schedule(course_id=2, teacher_id=2, campus_id=1, day_of_week=6, start_time="10:30", end_time="11:30", max_students=12, current_students=10, is_active=True),
        Schedule(course_id=4, teacher_id=1, campus_id=1, day_of_week=6, start_time="14:00", end_time="15:30", max_students=10, current_students=7, is_active=True),
        Schedule(course_id=5, teacher_id=1, campus_id=1, day_of_week=7, start_time="14:00", end_time="15:30", max_students=10, current_students=9, is_active=True),
        Schedule(course_id=8, teacher_id=3, campus_id=1, day_of_week=6, start_time="15:30", end_time="17:00", max_students=10, current_students=5, is_active=True),
        Schedule(course_id=1, teacher_id=2, campus_id=2, day_of_week=6, start_time="09:30", end_time="10:30", max_students=12, current_students=4, is_active=True),
        Schedule(course_id=4, teacher_id=1, campus_id=2, day_of_week=7, start_time="09:30", end_time="11:00", max_students=10, current_students=6, is_active=True),
        Schedule(course_id=3, teacher_id=2, campus_id=2, day_of_week=7, start_time="14:00", end_time="15:30", max_students=10, current_students=3, is_active=True),
        Schedule(course_id=7, teacher_id=1, campus_id=1, day_of_week=3, start_time="19:00", end_time="20:30", max_students=12, current_students=8, is_active=True),
        Schedule(course_id=9, teacher_id=4, campus_id=1, day_of_week=7, start_time="10:00", end_time="11:30", max_students=8, current_students=4, is_active=True),
    ]
    db.add_all(schedules)

    # FAQ
    faqs = [
        FAQ(category="报名", question="几岁可以开始学书法？", answer="硬笔书法5岁即可开始，毛笔书法建议6岁以上。5-7岁以培养兴趣和正确握笔姿势为主，7岁以上可以系统学习。", sort_order=1, is_active=True),
        FAQ(category="报名", question="没有基础可以学吗？", answer="完全可以！我们的启蒙班和入门班都是零基础起步，老师会从最基础的内容教起，循序渐进。", sort_order=2, is_active=True),
        FAQ(category="上课", question="一节课多长时间？", answer="少儿硬笔班60分钟/次，毛笔班和国画班90分钟/次。课程时长根据孩子注意力特点设计，保证学习效果。", sort_order=3, is_active=True),
        FAQ(category="上课", question="硬笔和毛笔先学哪个？", answer="5-7岁建议先学硬笔，打好规范书写基础；7岁以上如对传统文化感兴趣，可同时学习毛笔。两者相辅相成。", sort_order=4, is_active=True),
        FAQ(category="费用", question="学费包含什么？", answer="学费包含课时费、课堂用纸墨、学习资料。硬笔班需自备笔，毛笔班首期赠送文房四宝套装。", sort_order=5, is_active=True),
        FAQ(category="费用", question="可以退费吗？", answer="开课前可全额退费；开课后按未上课时比例退费。具体退费政策请咨询校区前台。", sort_order=6, is_active=True),
        FAQ(category="其他", question="有考级培训吗？", answer="有的！我们提供书法等级考试辅导，考级通过率95%以上，老师会根据学员水平推荐合适的考级等级。", sort_order=7, is_active=True),
        FAQ(category="其他", question="上课需要带什么？", answer="硬笔班自带铅笔/钢笔；毛笔班首期赠送文房四宝，后续自备毛笔和墨汁，纸张由中心提供；国画班画具由中心提供。", sort_order=8, is_active=True),
    ]
    db.add_all(faqs)

    # 优惠
    promos = [
        Promotion(title="新学期报名优惠", description="新学期报名享9折，老学员续费8.5折", discount_type="折扣", discount_value="新学员9折，老学员8.5折", start_date="2026-03-01", end_date="2026-06-30", conditions="每人限享一次，不与其他优惠叠加", is_active=True),
        Promotion(title="两人同行优惠", description="两人同时报名各减200元", discount_type="减免", discount_value="每人减200元", start_date="2026-01-01", end_date="2026-12-31", conditions="需同时报名同一课程", is_active=True),
        Promotion(title="体验课赠礼", description="预约体验课即赠精美书法练习册", discount_type="赠品", discount_value="赠送书法练习册", start_date="2026-01-01", end_date="2026-12-31", conditions="每位学员限领一次", is_active=True),
    ]
    db.add_all(promos)

    db.commit()
    db.close()
    print("✅ 种子数据插入完成")
