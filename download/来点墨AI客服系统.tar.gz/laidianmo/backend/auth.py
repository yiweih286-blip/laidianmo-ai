"""
来点墨 - 鉴权模块
JWT Token + SHA256 密码哈希
"""
import jwt
import hashlib
import secrets
from datetime import datetime, timedelta

SECRET_KEY = "laidianmo_2026_secret_change_in_production"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_HOURS = 24


def hash_password(password: str) -> str:
    """SHA256 + 随机盐值哈希"""
    salt = secrets.token_hex(16)
    h = hashlib.sha256((salt + password).encode()).hexdigest()
    return f"{salt}${h}"


def verify_password(plain: str, hashed: str) -> bool:
    """验证密码"""
    try:
        salt, h = hashed.split("$")
        return hashlib.sha256((salt + plain).encode()).hexdigest() == h
    except Exception:
        return False


def create_token(data: dict) -> str:
    """生成 JWT Token"""
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(hours=ACCESS_TOKEN_EXPIRE_HOURS)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> dict | None:
    """解码验证 JWT Token"""
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except jwt.PyJWTError:
        return None
