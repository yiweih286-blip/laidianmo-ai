"""
来点墨 - 智能检索服务
根据用户问题从数据库检索相关信息，作为LLM上下文
"""
from sqlalchemy.orm import Session
from models import Course, Teacher, Schedule, Campus, FAQ, Promotion, OrgInfo, Category

DAY_NAMES = {1:"周一",2:"周二",3:"周三",4:"周四",5:"周五",6:"周六",7:"周日"}


def retrieve(db: Session, query: str) -> str:
    """根据用户问题检索相关数据库内容，返回格式化文本"""
    parts = []
    q = f"%{query}%"

    # 机构信息（始终包含）
    org = db.query(OrgInfo).first()
    if org:
        info = f"【机构信息】\n名称：{org.name}"
        if org.slogan: info += f"\n标语：{org.slogan}"
        if org.intro: info += f"\n简介：{org.intro}"
        if org.phone: info += f"\n电话：{org.phone}"
        if org.wechat: info += f"\n微信：{org.wechat}"
        parts.append(info)

    # 课程
    courses = db.query(Course).filter(
        Course.is_active == True,
        (Course.name.like(q)) | (Course.description.like(q)) |
        (Course.category_id.in_(
            db.query(Category.id).filter(Category.name.like(q)).subquery()
        )) | (Course.age_range.like(q)) | (Course.level.like(q))
    ).limit(5).all()

    if not courses:
        courses = db.query(Course).filter(Course.is_active == True).limit(5).all()

    if courses:
        lines = ["【课程信息】"]
        for c in courses:
            cat = db.query(Category).filter(Category.id == c.category_id).first()
            line = f"{c.name}"
            if cat: line += f"（{cat.name}）"
            if c.age_range: line += f" | 适合{c.age_range}"
            if c.level: line += f" | {c.level}"
            if c.price: line += f" | {c.price}{c.price_unit}"
            if c.duration: line += f" | {c.duration}"
            if c.total_sessions: line += f" | 共{c.total_sessions}次课"
            if c.max_students: line += f" | 每班≤{c.max_students}人"
            if c.description: line += f"\n  描述：{c.description}"
            if c.highlights: line += f"\n  亮点：{c.highlights}"
            lines.append(line)
        parts.append("\n".join(lines))

    # 教师
    teachers = db.query(Teacher).filter(
        Teacher.is_active == True,
        (Teacher.name.like(q)) | (Teacher.specialties.like(q)) | (Teacher.title.like(q))
    ).limit(5).all()

    if not teachers:
        teachers = db.query(Teacher).filter(Teacher.is_active == True).limit(4).all()

    if teachers:
        lines = ["【教师信息】"]
        for t in teachers:
            line = f"{t.name}"
            if t.title: line += f"（{t.title}）"
            if t.specialties: line += f" | 擅长：{t.specialties}"
            if t.experience_years: line += f" | {t.experience_years}年教龄"
            if t.education: line += f" | 学历：{t.education}"
            if t.awards: line += f"\n  获奖：{t.awards}"
            if t.bio: line += f"\n  简介：{t.bio}"
            lines.append(line)
        parts.append("\n".join(lines))

    # 排课
    schedules = db.query(Schedule).filter(Schedule.is_active == True).limit(10).all()
    if schedules:
        lines = ["【排课信息】"]
        for s in schedules:
            course = db.query(Course).filter(Course.id == s.course_id).first()
            teacher = db.query(Teacher).filter(Teacher.id == s.teacher_id).first()
            campus = db.query(Campus).filter(Campus.id == s.campus_id).first() if s.campus_id else None
            day = DAY_NAMES.get(s.day_of_week, "未知")
            line = f"{day} {s.start_time}-{s.end_time}"
            if course: line += f" | {course.name}"
            if teacher: line += f" | {teacher.name}老师"
            if campus: line += f" | {campus.name}"
            if s.max_students: line += f" | {s.current_students or 0}/{s.max_students}人"
            lines.append(line)
        parts.append("\n".join(lines))

    # 校区
    campuses = db.query(Campus).filter(
        Campus.is_active == True,
        (Campus.name.like(q)) | (Campus.address.like(q))
    ).limit(3).all()
    if not campuses:
        campuses = db.query(Campus).filter(Campus.is_active == True).limit(3).all()
    if campuses:
        lines = ["【校区信息】"]
        for c in campuses:
            line = f"{c.name}"
            if c.address: line += f"\n  地址：{c.address}"
            if c.phone: line += f"\n  电话：{c.phone}"
            if c.business_hours: line += f"\n  营业：{c.business_hours}"
            if c.transportation: line += f"\n  交通：{c.transportation}"
            lines.append(line)
        parts.append("\n".join(lines))

    # FAQ
    faqs = db.query(FAQ).filter(
        FAQ.is_active == True,
        (FAQ.question.like(q)) | (FAQ.answer.like(q)) | (FAQ.category.like(q))
    ).limit(5).all()
    if faqs:
        lines = ["【常见问题】"]
        for f in faqs:
            lines.append(f"Q：{f.question}\nA：{f.answer}")
        parts.append("\n".join(lines))

    # 优惠
    promos = db.query(Promotion).filter(Promotion.is_active == True).limit(5).all()
    if promos:
        lines = ["【优惠活动】"]
        for p in promos:
            line = f"{p.title}"
            if p.discount_value: line += f" | {p.discount_value}"
            if p.conditions: line += f"\n  条件：{p.conditions}"
            if p.start_date or p.end_date:
                line += f"\n  期限：{p.start_date or '即日起'} 至 {p.end_date or '长期'}"
            lines.append(line)
        parts.append("\n".join(lines))

    return "\n\n".join(parts) if parts else "（数据库暂无数据）"
