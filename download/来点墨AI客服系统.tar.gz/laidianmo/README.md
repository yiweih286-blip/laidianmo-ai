# 来点墨书法艺术培训中心 - AI客服智能问答系统

## 架构

```
前后端分离，数据安全有保障

家长端（前端）  →  只能聊天和预约，看不到管理功能
管理端（前端）  →  需要密码登录，JWT Token鉴权
后端 API       →  所有数据操作必须经过鉴权
SQLite 数据库  →  存储在服务器端，前端无法直接访问
```

## 安全设计

| 措施 | 说明 |
|------|------|
| **前后端分离** | 家长端零管理入口，管理端独立页面 |
| **JWT鉴权** | 管理接口必须携带有效Token，否则401拒绝 |
| **密码哈希** | SHA256+随机盐值，不可逆 |
| **Token过期** | 24小时自动失效，需重新登录 |
| **数据在服务端** | SQLite数据库在服务器，前端无法直接读写 |

## 快速启动

### 前提：安装 Python 3.10+ 和 pip

```bash
# 1. 进入后端目录
cd backend

# 2. 安装依赖
pip3 install fastapi uvicorn sqlalchemy pyjwt

# 3. 启动服务
python3 -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

### 访问地址

| 页面 | 地址 | 说明 |
|------|------|------|
| 家长端 | http://localhost:8000 | 聊天咨询，无需登录 |
| 管理端 | http://localhost:8000/admin | 需要密码登录 |
| API文档 | http://localhost:8000/docs | 开发者参考 |

### 默认管理员

- 用户名：`admin`
- 密码：`admin123`
- ⚠️ 首次登录后请立即修改密码！

## 项目结构

```
laidianmo/
├── backend/
│   ├── main.py          # FastAPI 主应用（所有API路由）
│   ├── models.py        # 数据库模型（9张表）
│   ├── auth.py          # JWT鉴权 + 密码哈希
│   ├── retriever.py     # 智能检索服务
│   ├── llm.py           # LLM对话服务
│   ├── seed.py          # 种子数据（示例数据）
│   ├── start.sh         # 启动脚本
│   └── data/
│       └── laidianmo.db # SQLite数据库（运行后生成）
├── frontend/
│   ├── index.html       # 家长端聊天界面
│   └── admin.html       # 管理后台界面
└── README.md
```

## 数据库表

| 表 | 说明 | 管理端可操作 |
|----|------|-------------|
| admins | 管理员账号 | 改密码 |
| categories | 课程分类 | 增删改 |
| courses | 课程信息 | 增删改 |
| teachers | 教师信息 | 增删改 |
| schedules | 排课信息 | 增删改 |
| campuses | 校区信息 | 增删改 |
| faqs | 常见问题 | 增删改 |
| promotions | 优惠活动 | 增删改 |
| trial_bookings | 体验课预约 | 查看状态 |
| org_info | 机构信息 | 修改 |

## API 接口

### 公开接口（家长端，无需登录）
- `POST /api/chat` — AI对话
- `GET /api/courses` — 课程列表
- `GET /api/campuses` — 校区列表
- `POST /api/trial-booking` — 预约体验课

### 管理接口（需JWT Token）
- `POST /api/admin/login` — 登录获取Token
- `POST /api/admin/change-password` — 修改密码
- `GET/POST/PUT/DELETE /api/admin/{表名}` — 数据CRUD

## 后期数据录入

1. 打开管理端 http://localhost:8000/admin
2. 用管理员账号登录
3. 在左侧菜单选择要管理的模块
4. 填写表单，点击添加
5. 数据实时生效，家长端立刻能查到
